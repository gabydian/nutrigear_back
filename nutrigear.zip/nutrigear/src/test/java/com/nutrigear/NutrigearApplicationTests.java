package com.nutrigear;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutrigearApplicationTests {

	@Test
	void contextLoads() {
	}

}
